-- Neovim syntax file
-- Language:	Treesitter query

-- it's a lisp!
vim.cmd([[runtime! syntax/lisp.vim]])
